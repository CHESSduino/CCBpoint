/* multiRead.h
 */
#ifndef MULTIREAD_H
#define MULTIREAD_H

#define MAX_ADDRESS_AMOUNT 	64
#define ID_AMOUT			5

#include <RFID_IIC.h>


class RFID_MULTIREAD
{
  public:
  	RFID_MULTIREAD(unsigned char* arr_addr, int _addr_amount);
  	void init();
  	void scan();
  	void compare();
    void compare(unsigned char *des);
  	void debugswitch(bool enable) {enable_debug = enable;};
  	unsigned char id[MAX_ADDRESS_AMOUNT][ID_AMOUT];
	void printAllID();
	
  private:
  	unsigned char addr[MAX_ADDRESS_AMOUNT];
  	int addr_amount = 0;
  	RFID *card[MAX_ADDRESS_AMOUNT];
  	unsigned char id_pre[MAX_ADDRESS_AMOUNT][ID_AMOUT];
  	bool enable_debug = false;

  	bool id_equal(unsigned char* id1, unsigned char* id2);
  	void printID(unsigned char* id);

};


#endif