/* RFID.h - Library to use ARDUINO RFID MODULE KIT 13.56 MHZ WITH TAGS SPI W AND R BY COOQROBOT.
 * Based on code Dr.Leong   ( WWW.B2CQSHOP.COM )
 * Created by Miguel Balboa (circuitito.com), Jan, 2012. 
 * ÕûÀíÕß£ºCai_Niao
 * ÕûÀíÊ±¼ä£º2015.10.11
 */
#ifndef RFID_h
#define RFID_h


#define RFID_IIC 
//#define ENABLE_RESET

#include <Arduino.h>

#ifdef RFID_IIC
#else
#endif

#ifdef RFID_IIC
 #include "I2Cdev.h"
 #define RFID_IIC_DEFAULT_ADDR 0x00
#else
 #include <SPI.h>
#endif



/******************************************************************************
 * ¶¨Òå
 ******************************************************************************/
#define MAX_LEN 16   // Êý×é×î´ó³¤¶È

//MF522ÃüÁî×Ö
#define PCD_IDLE              0x00               //ÎÞ¶¯×÷£¬È¡Ïûµ±Ç°ÃüÁî
#define PCD_AUTHENT           0x0E               //ÑéÖ¤ÃÜÔ¿
#define PCD_RECEIVE           0x08               //½ÓÊÕÊý¾Ý
#define PCD_TRANSMIT          0x04               //·¢ËÍÊý¾Ý
#define PCD_TRANSCEIVE        0x0C               //·¢ËÍ²¢½ÓÊÕÊý¾Ý
#define PCD_RESETPHASE        0x0F               //¸´Î»
#define PCD_CALCCRC           0x03               //CRC¼ÆËã

//Mifare_One¿¨Æ¬ÃüÁî×Ö
#define PICC_REQIDL           0x26               //Ñ°ÌìÏßÇøÄÚÎ´½øÈëÐÝÃß×´Ì¬
#define PICC_REQALL           0x52               //Ñ°ÌìÏßÇøÄÚÈ«²¿¿¨
#define PICC_ANTICOLL         0x93               //·À³å×²
#define PICC_SElECTTAG        0x93               //Ñ¡¿¨
#define PICC_AUTHENT1A        0x60               //ÑéÖ¤AÃÜÔ¿
#define PICC_AUTHENT1B        0x61               //ÑéÖ¤BÃÜÔ¿
#define PICC_READ             0x30               //¶Á¿é
#define PICC_WRITE            0xA0               //Ð´¿é
#define PICC_DECREMENT        0xC0               
#define PICC_INCREMENT        0xC1               
#define PICC_RESTORE          0xC2               //µ÷¿éÊý¾Ýµ½»º³åÇø
#define PICC_TRANSFER         0xB0               //±£´æ»º³åÇøÖÐÊý¾Ý
#define PICC_HALT             0x50               //ÐÝÃß
 
//ºÍMF522Í¨Ñ¶Ê±·µ»ØµÄ´íÎó´úÂë
#define MI_OK                 0
#define MI_NOTAGERR           1
#define MI_ERR                2


//------------------MFRC522¼Ä´æÆ÷---------------
//Page 0:Command and Status
#define     Reserved00            0x00    
#define     CommandReg            0x01    
#define     CommIEnReg            0x02    
#define     DivlEnReg             0x03    
#define     CommIrqReg            0x04    
#define     DivIrqReg             0x05
#define     ErrorReg              0x06    
#define     Status1Reg            0x07    
#define     Status2Reg            0x08    
#define     FIFODataReg           0x09
#define     FIFOLevelReg          0x0A
#define     WaterLevelReg         0x0B
#define     ControlReg            0x0C
#define     BitFramingReg         0x0D
#define     CollReg               0x0E
#define     Reserved01            0x0F
//Page 1:Command     
#define     Reserved10            0x10
#define     ModeReg               0x11
#define     TxModeReg             0x12
#define     RxModeReg             0x13
#define     TxControlReg          0x14
#define     TxAutoReg             0x15
#define     TxSelReg              0x16
#define     RxSelReg              0x17
#define     RxThresholdReg        0x18
#define     DemodReg              0x19
#define     Reserved11            0x1A
#define     Reserved12            0x1B
#define     MifareReg             0x1C
#define     Reserved13            0x1D
#define     Reserved14            0x1E
#define     SerialSpeedReg        0x1F
//Page 2:CFG    
#define     Reserved20            0x20  
#define     CRCResultRegM         0x21
#define     CRCResultRegL         0x22
#define     Reserved21            0x23
#define     ModWidthReg           0x24
#define     Reserved22            0x25
#define     RFCfgReg              0x26
#define     GsNReg                0x27
#define     CWGsPReg              0x28
#define     ModGsPReg             0x29
#define     TModeReg              0x2A
#define     TPrescalerReg         0x2B
#define     TReloadRegH           0x2C
#define     TReloadRegL           0x2D
#define     TCounterValueRegH     0x2E
#define     TCounterValueRegL     0x2F
//Page 3:TestRegister     
#define     Reserved30            0x30
#define     TestSel1Reg           0x31
#define     TestSel2Reg           0x32
#define     TestPinEnReg          0x33
#define     TestPinValueReg       0x34
#define     TestBusReg            0x35
#define     AutoTestReg           0x36
#define     VersionReg            0x37
#define     AnalogTestReg         0x38
#define     TestDAC1Reg           0x39  
#define     TestDAC2Reg           0x3A   
#define     TestADCReg            0x3B   
#define     Reserved31            0x3C   
#define     Reserved32            0x3D   
#define     Reserved33            0x3E   
#define     Reserved34            0x3F
//-----------------------------------------------

class RFID
{
  public:
  	#ifdef RFID_IIC
  		RFID(int NRSTPD, int addr = RFID_IIC_DEFAULT_ADDR);
	#else
		RFID(int chipSelectPin, int NRSTPD);
	#endif
	

	bool isCard();
	bool readCardSerial();
	void init();
	void reset();
	void setBitMask(unsigned char reg, unsigned char mask);
	void clearBitMask(unsigned char reg, unsigned char mask);
	void antennaOn(void);
	void antennaOff(void);
	void calculateCRC(unsigned char *pIndata, unsigned char len, unsigned char *pOutData);
	void writeMFRC522(unsigned char addr, unsigned char val);
	unsigned char readMFRC522(unsigned char addr);
	unsigned char MFRC522Request(unsigned char reqMode, unsigned char *TagType);
	unsigned char MFRC522ToCard(unsigned char command, unsigned char *sendData, unsigned char sendLen, unsigned char *backData, unsigned int *backLen);
	unsigned char anticoll(unsigned char *serNum);
	unsigned char auth(unsigned char authMode, unsigned char BlockAddr, unsigned char *Sectorkey, unsigned char *serNum);
	unsigned char read(unsigned char blockAddr, unsigned char *recvData);
	unsigned char write(unsigned char blockAddr, unsigned char *writeData);
	unsigned char selectTag(unsigned char *serNum);
	void halt();
	
	unsigned char serNum[5];       // 4×Ö½Ú¿¨ÐòÁÐºÅ£¬µÚ5×Ö½ÚÎªÐ£Ñé×Ö½Ú
	void printReg();
	void test();
	
  private:
  	#ifdef RFID_IIC
  	int _iicAddr;
  	uint8_t buffer[2];
	#else
	int _chipSelectPin;
	
	#endif
	int _NRSTPD;
	
};

#endif