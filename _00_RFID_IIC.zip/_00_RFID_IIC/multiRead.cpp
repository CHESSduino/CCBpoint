/*
*read multi IDs from RFID
 */


#include <multiRead.h>

RFID_MULTIREAD::RFID_MULTIREAD(unsigned char* arr_addr, int _addr_amount){
	memcpy(addr, arr_addr, _addr_amount);
	addr_amount = _addr_amount;
	for(int i = 0; i < addr_amount; i++){
		card[i] = new RFID(-1, addr[i]);
	}
}

void RFID_MULTIREAD::init(){
	for(int i = 0; i < addr_amount; i++){
		card[i] -> init();
	}
}

void RFID_MULTIREAD::scan(){
	for(int i = 0; i < addr_amount; i++){
		// Serial.print("Scaning ");
	 //    Serial.println(addr[i], HEX);
		if (card[i]->isCard()) {
			if (enable_debug){
		    	Serial.print("Find card in ");
		    	Serial.println(i);				
			}

		    //读取卡序列号
		    if (card[i]->readCardSerial()) {
		    	if (enable_debug){
		    		Serial.print("The card's number is  : ");
					Serial.print(card[i]->serNum[0],HEX);
					Serial.print(card[i]->serNum[1],HEX);
					Serial.print(card[i]->serNum[2],HEX);
					Serial.print(card[i]->serNum[3],HEX);
					Serial.print(card[i]->serNum[4],HEX);
					Serial.println(" ");
		    	}
		    	memcpy(id[i], card[i]->serNum, 5);
		    }
		    //选卡，可返回卡容量（锁定卡片，防止多数读取），去掉本行将连续读卡
		    //card[i]->selectTag(card[i]->serNum);
		  }
		  else{
		  	if (enable_debug){
		    	Serial.print("no card");
		    	Serial.println(i);				
			}
		  	memset(id[i], 0x00, 5);
		  }
	  	card[i]->halt();
	}
}

void RFID_MULTIREAD::compare(){
	for(int i = 0; i < addr_amount; i++){
		if(!id_equal(id[i], id_pre[i])){
			Serial.print(i+1);
			Serial.print(":");
			printID(id[i]);
			Serial.println("");
			memcpy(id_pre[i], id[i], 5);
		}
	}
}

void RFID_MULTIREAD::compare(unsigned char *des){
	for(int i = 0; i < addr_amount; i++){
		if(!id_equal(id[i], id_pre[i])){
			des[0] = i+1;
			des[1] = ':';
			memcpy(des+2, id[i], 5);
			memcpy(id_pre[i], id[i], 5);
		}
	}
}
bool RFID_MULTIREAD::id_equal(unsigned char* id1, unsigned char* id2){
	for(int i = 0;i < ID_AMOUT; i++){
		if(id1[i] != id2[i]) return false;
	}
	return true;
}
void RFID_MULTIREAD::printID(unsigned char* id){
	for(int i = 0; i < ID_AMOUT; i++){
		Serial.print(id[i],HEX);
	}
}
void RFID_MULTIREAD::printAllID(){
	for(int i =0; i < addr_amount; i++){
		Serial.print("No.");
		Serial.print(i);
		Serial.print(" card number is  : ");
		printID(id[i]);
		Serial.println("");
 	}
}